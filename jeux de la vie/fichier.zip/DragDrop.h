#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <string>
#include "Grille.h" 



class DragDrop
{
private:

public :

	int diff_deplacement_x;
	int diff_deplacement_y



};

